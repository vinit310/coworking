#!/bin/bash

setx DB_USERNAME wd_user
setx DB_PASSWORD 12345678
setx DB_HOST 127.0.0.1
setx DB_PORT 5433
setx DB_NAME wd_coworking_db